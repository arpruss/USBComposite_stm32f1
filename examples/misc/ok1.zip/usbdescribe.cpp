#include <stdio.h>

typedef unsigned char uint8;

template<uint8... args>struct USBCompositeComponent {
    unsigned numEndpoints;
    unsigned numInterfaces;
    const static unsigned descriptor_config_size;
    const static uint8 descriptor_config[];
};

template<uint8... args>const uint8 USBCompositeComponent<args...>::descriptor_config[] { args... };
template<uint8... args>const unsigned USBCompositeComponent<args...>::descriptor_config_size { (unsigned int)sizeof...(args) };

USBCompositeComponent<1,2,3> alpha;
main() {
    printf("%d %d", alpha.descriptor_config_size, alpha.descriptor_config[1]);
}